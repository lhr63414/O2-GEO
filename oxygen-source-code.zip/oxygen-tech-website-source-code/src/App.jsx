import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Menu, X, User, LogIn, Mail, Phone, MapPin, MessageSquare, Newspaper, BookOpen, Video, Sparkles, PenTool, Globe2, CalendarDays, Eye, ArrowLeft } from 'lucide-react'
import './App.css'
import './stream-section.css'
import LogoLoop from './components/LogoLoop'
import logoImage from './assets/logo_transparent.png'
import cooperationCases from './assets/cooperation_cases_technology.png' // 引入合作案例图片
import footerLogos from './assets/footer_logos.png' // 引入页脚Logo墙图片
import geoPublishFull from './assets/geo_publish_full.webp'
import doubaoLogo from './assets/doubao_logo.png';
import tongyiLogo from './assets/tongyi_logo.png';
import deepseekLogo from './assets/deepseek_logo.png';
import yuanbaoLogo from './assets/yuanbao_logo.png';
import kimiLogo from './assets/kimi_logo.png';
import wechatQrcode from './assets/wechat_qrcode.png'; // 导入微信二维码图片
import chatgptLogo from './assets/chatgpt_logo.png';
import perplexityLogo from './assets/perplexity_logo.png';
import companyNews from './data/companyNews'

const BG_VIDEO = '/hero-liquid-glass.mp4'

const SectionGlobalStrip = ({ items }) => (
  <div className="section-global-strip" aria-hidden="true">
    {items.map((item, index) => (
      <span key={item} className="section-global-strip-item">
        {item}
        {index < items.length - 1 && <i />}
      </span>
    ))}
  </div>
)

const GlobalMetricCard = ({ value, label, meta }) => (
  <div className="global-metric-card">
    <span>{value}</span>
    <p>{label}</p>
    <em>{meta}</em>
  </div>
)

const aiPlatformLogos = [
  { src: chatgptLogo, alt: 'ChatGPT', title: 'ChatGPT' },
  { src: deepseekLogo, alt: 'DeepSeek', title: 'DeepSeek' },
  { src: kimiLogo, alt: 'KIMI', title: 'KIMI' },
  { src: yuanbaoLogo, alt: '元宝', title: '元宝' },
  { src: doubaoLogo, alt: '豆包', title: '豆包' },
  { src: tongyiLogo, alt: '通义千问', title: '通义千问' },
  { src: perplexityLogo, alt: 'Perplexity', title: 'Perplexity' },
]

const renderAiPlatformLogo = item => (
  <div className="ai-logo-card">
    <div className="ai-logo-card-icon">
      <img src={item.src} alt={item.alt} />
    </div>
    <p>{item.title}</p>
  </div>
)

const ArticleContentBlock = ({ block, articleTitle, index }) => {
  if (typeof block === 'string') {
    return <p>{block}</p>
  }

  if (block.type === 'html') {
    return <div className="wechat-article-html" dangerouslySetInnerHTML={{ __html: block.html }} />
  }

  if (block.type === 'image') {
    return (
      <figure className="news-detail-image-block">
        <img src={block.src} alt={block.alt || `${articleTitle} 配图 ${index + 1}`} />
      </figure>
    )
  }

  return <p>{block.text}</p>
}

const NewsCard = ({ item, index }) => (
  <a
    href={`#news/article/${index}`}
    className="news-card"
    aria-label={`查看文章：${item.title}`}
  >
    <div className="news-cover">
      <img src={item.image} alt={item.title} referrerPolicy="no-referrer" />
      <span>{item.category}</span>
    </div>
    <div className="news-card-body">
      <p className="news-card-category">#{item.category}</p>
      <h3>{item.title}</h3>
      <p>{item.desc}</p>
      <div className="news-card-meta">
        <span><CalendarDays size={14} />{item.date}</span>
        <span><Eye size={14} />阅读 {item.views}</span>
      </div>
    </div>
  </a>
)

const getArticleIndexFromHash = () => {
  if (typeof window === 'undefined') return null
  const match = window.location.hash.match(/^#news\/article\/(\d+)$/)
  if (!match) return null
  const index = Number(match[1])
  return Number.isInteger(index) && companyNews[index] ? index : null
}

const getNewsArchiveFromHash = () => {
  if (typeof window === 'undefined') return false
  return window.location.hash === '#news/more'
}

const getGemGlobalPageFromHash = () => {
  if (typeof window === 'undefined') return false
  return window.location.hash === '#gem-global'
}

const NewsArticleContent = ({ article }) => {
  const [htmlContent, setHtmlContent] = useState('')
  const [loadError, setLoadError] = useState(false)

  useEffect(() => {
    let isMounted = true
    setHtmlContent('')
    setLoadError(false)

    if (!article.contentHtmlPath) {
      return undefined
    }

    fetch(article.contentHtmlPath)
      .then((response) => {
        if (!response.ok) throw new Error('文章内容加载失败')
        return response.text()
      })
      .then((html) => {
        if (isMounted) setHtmlContent(html)
      })
      .catch(() => {
        if (isMounted) setLoadError(true)
      })

    return () => {
      isMounted = false
    }
  }, [article])

  if (article.contentHtmlPath) {
    if (loadError) return <p>正文暂时无法加载，请刷新页面重试。</p>
    if (!htmlContent) return <p>正文加载中...</p>
    return <div className="wechat-article-html" dangerouslySetInnerHTML={{ __html: htmlContent }} />
  }

  return article.content?.map((block, index) => (
    <ArticleContentBlock
      key={index}
      block={block}
      articleTitle={article.title}
      index={index}
    />
  ))
}

const NewsArticlePage = ({ article }) => (
  <main className="news-detail-page">
    <section className="news-detail-hero">
      <div className="container-custom">
        <a href="#news/more" className="news-detail-back">
          <ArrowLeft size={18} />
          返回企业动态
        </a>
        <div className="news-detail-layout">
          <div className="news-detail-copy">
            <p className="news-detail-kicker">{article.category}</p>
            <h1>{article.title}</h1>
            <div className="news-detail-byline">
              <span>氧气科技</span>
              <span>时间：{article.date}</span>
              <span><Eye size={15} />阅读 {article.views}</span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section className="news-detail-content-section">
      <div className="container-custom">
        <article className="news-detail-article">
          <div className="article-modal-content news-detail-content">
            <NewsArticleContent article={article} />
          </div>
        </article>
      </div>
    </section>
  </main>
)

const NewsArchivePage = ({ articles }) => (
  <main className="news-archive-page">
    <section className="news-archive-hero">
      <div className="container-custom">
        <a href="#news" className="news-detail-back">
          <ArrowLeft size={18} />
          返回首页企业动态
        </a>
        <div className="news-archive-head">
          <div>
            <p>News & Insights</p>
            <h1>企业动态</h1>
          </div>
          <span>{articles.length} 篇文章</span>
        </div>
      </div>
    </section>
    <section className="news-archive-list-section">
      <div className="container-custom">
        <div className="news-card-grid news-archive-grid">
          {articles.map((item, index) => (
            <NewsCard key={item.url || item.title} item={item} index={index} />
          ))}
        </div>
      </div>
    </section>
  </main>
)

const GemGlobalPage = () => {
  const auditItems = [
    '是否被 AI 自然提及',
    '是否被准确描述',
    '是否与竞品共同出现',
    '是否在高意图问题中缺席',
    '是否具备清晰转化承接路径',
  ]

  const serviceLayers = [
    {
      label: 'GEO',
      title: '让品牌被 AI 读取、引用和推荐',
      desc: '通过官网内容结构优化、FAQ 与场景化问题布局、品牌语义强化、案例与第三方证据补充、多语言内容适配，提升品牌在 AI 自然回答中的可信可见度。',
      points: ['内容结构优化', '场景化问题布局', '品牌语义强化', '第三方证据补充', '多语言内容适配'],
    },
    {
      label: 'GEM',
      title: '让品牌进入 AI 付费搜索与对话营销机会',
      desc: '进一步关注 AI 付费搜索、赞助广告位和对话式营销机会，识别值得投放的问题、可切入的场景、可抢占的竞品空白位，并形成投放到转化的闭环。',
      points: ['AI 付费搜索', '赞助广告位', '对话式营销', '竞品空白位抢占', '广告与落地页闭环'],
    },
  ]

  const loopSteps = [
    { title: '识别', desc: '从品牌当前在 AI 回答中的露出情况出发，评估自然提及、描述准确度与竞品共现关系。' },
    { title: '优化', desc: '重新整理品牌在 AI 世界里的可被理解资产，让模型更容易验证、引用和推荐。' },
    { title: '投放', desc: '判断哪些高意图问题值得投放，哪些对话场景可以进入，哪些广告内容应优先测试。' },
    { title: '转化', desc: '把自然回答、赞助曝光、落地页与转化动作串成闭环，提前进入用户决策链路。' },
  ]

  const gemFaqs = [
    {
      question: 'GEM 和 GEO 是什么关系？',
      answer: 'GEO 侧重提升品牌被 AI 自然读取、引用和推荐的概率；GEM 在此基础上进一步管理 AI 付费搜索、赞助广告位和对话式营销机会，帮助品牌形成自然可见度与商业转化的双层闭环。',
    },
    {
      question: '为什么出海品牌需要 GEM？',
      answer: '用户正在通过 ChatGPT、Gemini、Perplexity、Claude 等生成式入口完成信息筛选和购买判断。GEM 的目标是让品牌在用户真正做决定之前，已经进入 AI 的推荐范围和用户的信任名单。',
    },
    {
      question: '氧气科技会如何判断品牌当前状态？',
      answer: '我们会评估品牌是否被 AI 自然提及、是否被准确描述、是否与竞品共同出现、是否在高意图问题中缺席，以及是否具备清晰的转化承接路径。',
    },
    {
      question: 'GEM 服务最终解决什么问题？',
      answer: 'GEM 帮助品牌识别哪些问题值得投放、哪些场景可以切入、哪些竞品空白位可以抢占，并让广告内容与自然回答、落地页和转化动作形成闭环。',
    },
  ]

  return (
    <main className="gem-global-page">
      <section className="gem-global-hero">
        <div className="container-custom" data-reveal>
          <a href="#home" className="news-detail-back">
            <ArrowLeft size={18} />
            返回官网首页
          </a>
          <div className="gem-global-hero-grid">
            <div className="gem-global-copy">
              <p className="gem-global-eyebrow">GLOBAL GEM + GEO SERVICE</p>
              <h1>氧气科技全球 GEM + GEO 服务</h1>
              <p>
                帮助出海品牌和全球化企业重新整理自己在 AI 世界里的“可被理解资产”，在用户真正做决定之前，进入 AI 的推荐范围和用户的信任名单。
              </p>
              <div className="gem-global-platforms" aria-label="全球生成式入口">
                <span>ChatGPT</span>
                <span>Gemini</span>
                <span>Perplexity</span>
                <span>Claude</span>
              </div>
              <div className="gem-global-actions">
                <a href="#contact" className="gem-primary-action">咨询 GEM 服务</a>
                <a href="#gem-global-method" className="gem-secondary-action">查看服务框架</a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="gem-global-section gem-global-audit">
        <div className="container-custom" data-reveal>
          <div className="gem-global-section-head">
            <p>AI 可见度诊断</p>
            <h2>先判断品牌是否已经进入 AI 的理解与推荐链路</h2>
          </div>
          <div className="gem-audit-grid">
            {auditItems.map((item, index) => (
              <div key={item} className="gem-audit-card">
                <span>{String(index + 1).padStart(2, '0')}</span>
                <p>{item}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="gem-global-method" className="gem-global-section gem-service-layers">
        <div className="container-custom" data-reveal>
          <div className="gem-global-section-head">
            <p>GEO + GEM 双层服务</p>
            <h2>从自然可见度到付费搜索机会，构建全球 AI 增长闭环</h2>
          </div>
          <div className="gem-layer-grid">
            {serviceLayers.map((layer) => (
              <article key={layer.label} className="gem-layer-card">
                <div>
                  <span>{layer.label}</span>
                  <h3>{layer.title}</h3>
                  <p>{layer.desc}</p>
                </div>
                <ul>
                  {layer.points.map((point) => (
                    <li key={point}>{point}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="gem-global-section gem-loop-section">
        <div className="container-custom" data-reveal>
          <div className="gem-global-section-head">
            <p>AI 决策链路运营</p>
            <h2>让内容被机器理解、被模型验证、被用户信任</h2>
          </div>
          <div className="gem-loop-grid">
            {loopSteps.map((step, index) => (
              <div key={step.title} className="gem-loop-card">
                <span>{index + 1}</span>
                <h3>{step.title}</h3>
                <p>{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="gem-global-section gem-faq-section">
        <div className="container-custom" data-reveal>
          <div className="gem-global-section-head">
            <p>FAQ</p>
            <h2>关于 GEM 的常见问题</h2>
          </div>
          <div className="gem-faq-grid">
            {gemFaqs.map((item) => (
              <article key={item.question} className="gem-faq-card">
                <h3>{item.question}</h3>
                <p>{item.answer}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="gem-global-cta">
        <div className="container-custom" data-reveal>
          <div className="gem-global-cta-panel">
            <p>Oxygen Technology</p>
            <h2>让全球品牌在 AI 时代被看见、被理解、被推荐</h2>
            <span>并更早进入用户决策链路。</span>
            <a href="#contact">联系氧气科技 →</a>
          </div>
        </div>
      </section>
    </main>
  )
}

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false)
  const [isWechatHovered, setIsWechatHovered] = useState(false) // 新增微信悬浮状态
  const [scrollProgress, setScrollProgress] = useState(0)
  const [activeArticleIndex, setActiveArticleIndex] = useState(getArticleIndexFromHash)
  const [isNewsArchiveOpen, setIsNewsArchiveOpen] = useState(getNewsArchiveFromHash)
  const [isGemGlobalPageOpen, setIsGemGlobalPageOpen] = useState(getGemGlobalPageFromHash)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
      const maxScroll = document.documentElement.scrollHeight - window.innerHeight
      setScrollProgress(maxScroll > 0 ? window.scrollY / maxScroll : 0)
    }
    window.addEventListener('scroll', handleScroll)
    handleScroll()
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    const handleHashChange = () => {
      setActiveArticleIndex(getArticleIndexFromHash())
      setIsNewsArchiveOpen(getNewsArchiveFromHash())
      setIsGemGlobalPageOpen(getGemGlobalPageFromHash())
    }

    window.addEventListener('hashchange', handleHashChange)
    handleHashChange()

    return () => window.removeEventListener('hashchange', handleHashChange)
  }, [])

  useEffect(() => {
    const revealObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible')
            revealObserver.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.14 }
    )

    document.querySelectorAll('[data-reveal]').forEach((element) => {
      revealObserver.observe(element)
    })

    return () => revealObserver.disconnect()
  }, [activeArticleIndex, isNewsArchiveOpen, isGemGlobalPageOpen])

  useEffect(() => {
    const hero = document.getElementById('home')
    if (!hero) return undefined

    const handlePointerMove = (event) => {
      const rect = hero.getBoundingClientRect()
      const x = (event.clientX - rect.left) / rect.width - 0.5
      const y = (event.clientY - rect.top) / rect.height - 0.5
      hero.style.setProperty('--hero-x', x.toFixed(3))
      hero.style.setProperty('--hero-y', y.toFixed(3))
    }

    const resetPointer = () => {
      hero.style.setProperty('--hero-x', '0')
      hero.style.setProperty('--hero-y', '0')
    }

    hero.addEventListener('pointermove', handlePointerMove)
    hero.addEventListener('pointerleave', resetPointer)
    resetPointer()

    return () => {
      hero.removeEventListener('pointermove', handlePointerMove)
      hero.removeEventListener('pointerleave', resetPointer)
    }
  }, [])

  const activeArticle = activeArticleIndex !== null ? companyNews[activeArticleIndex] : null
  const featuredNews = companyNews.filter((item) => item.featured).slice(0, 3)

  useEffect(() => {
    if (activeArticle || isNewsArchiveOpen || isGemGlobalPageOpen) {
      window.scrollTo({ top: 0, behavior: 'auto' })
    }
  }, [activeArticle, isNewsArchiveOpen, isGemGlobalPageOpen])

  useEffect(() => {
    if (activeArticle || isNewsArchiveOpen || isGemGlobalPageOpen) return
    const sectionId = window.location.hash.replace('#', '')
    if (!sectionId || sectionId.includes('/')) return

    const scrollToHashSection = () => {
      document.getElementById(sectionId)?.scrollIntoView({ behavior: 'auto', block: 'start' })
    }

    const timers = [0, 120, 360, 900].map((delay) => window.setTimeout(scrollToHashSection, delay))
    return () => timers.forEach((timer) => window.clearTimeout(timer))
  }, [activeArticle, isNewsArchiveOpen, isGemGlobalPageOpen])

  const scrollToSection = (id) => {
    setIsMenuOpen(false)

    if (activeArticle || isNewsArchiveOpen || isGemGlobalPageOpen) {
      setActiveArticleIndex(null)
      setIsNewsArchiveOpen(false)
      setIsGemGlobalPageOpen(false)
      window.location.hash = id
      window.setTimeout(() => {
        document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
      }, 0)
      return
    }

    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  const streamData = [
    {
      letter: 'S',
      title: '语义结构化指数',
      english: 'Semantic Structuring',
      desc: '提升内容的语义组织与结构化程度，确保信息易于理解和检索。通过规范化标签和分类，优化搜索引擎的抓取。',
      bullets: [
        '提升内容的语义组织与结构化程度；',
        '让AI更容易理解品牌、产品、场景与关键词之间的关系；',
        '优化模型抓取与调用效率。'
      ]
    },
    {
      letter: 'T',
      title: '时间新鲜度因子',
      english: 'Timeliness',
      desc: '定期更新内容，确保信息时效性，紧跟行业动态，保持信息的新鲜度。建立内容更新日历，并根据用户反馈和数据分析进行调整。',
      bullets: [
        '保持信息持续更新；',
        '强化内容时效性与版本一致性；',
        '让模型优先使用最新、有效、可验证的信息。'
      ]
    },
    {
      letter: 'R',
      title: '可信源交叉认证数',
      english: 'Redundant Trust',
      desc: '增加权威背书，提升内容可信度。引用行业报告、专家观点和权威数据，增加内容的专业性和说服力。',
      bullets: [
        '通过官网、媒体、报告、专家、用户口碑等多源交叉验证；',
        '提升品牌信息可信度；',
        '增强AI引用和推荐信心。'
      ]
    },
    {
      letter: 'E',
      title: '用户共鸣指数',
      english: 'Engagement',
      desc: '深入研究用户需求，建立双向沟通。通过社交媒体互动、用户调查和反馈收集，了解用户痛点和需求，并及时响应。',
      bullets: [
        '聚焦真实用户问题、痛点与高频意图；',
        '用更贴近搜索提问方式的内容表达；',
        '提升内容与需求的匹配度。'
      ]
    },
    {
      letter: 'A',
      title: '内容一致性得分',
      english: 'Alignment',
      desc: '确保品牌信息在不同平台的一致性，包括官方网站、社交媒体、广告宣传等，避免信息碎片化和歧义。',
      bullets: [
        '确保官网、社媒、电商、新闻稿等多平台表达一致；',
        '统一品牌叙事与产品描述；',
        '避免模型理解偏差。'
      ]
    },
    {
      letter: 'M',
      title: '多模态搜索权重动态微调算法',
      english: 'Multimodal Weighting',
      desc: '优化品牌在多模态搜索中的表现，包括文本、图像、语音等多种搜索方式，提升品牌曝光度和用户触达率。',
      bullets: [
        '兼顾文本、图像、视频、问答等多模态内容；',
        '提升在多模态搜索与推荐场景中的表现；',
        '增强综合可见性与用户体验。'
      ]
    },
  ];

  const geoPublishFeatures = [
    { title: '方便快捷', desc: '一键发布，简洁易用的24小时自助发布平台' },
    { title: '全网覆盖', desc: '上万家媒体资源一键发布且每日不断更新中' },
    { title: '高性价比', desc: '一手网络媒体资源节省50%以上推广成本' },
    { title: '极速投放', desc: '24小时内响应投放需求，效率高、服务好、质量优' },
    { title: '全网覆盖', desc: '专业为各大媒介、公关、传媒互联网企业提供完善的服务' },
    { title: '高性价比', desc: '正规流程，正规合同，正规发票，企业定制' },
  ];

  const geoPublishResources = [
    { icon: Newspaper, title: '自媒体', desc: '彻底打破行业信息差通道，直接邀请资源网站方入驻平台联盟合作，让服务更直接更靠谱' },
    { icon: BookOpen, title: '小红书', desc: '专业小红书推广、资深小红书服务商' },
    { icon: MessageSquare, title: '微信/微博', desc: '社交媒体全覆盖' },
    { icon: Video, title: '短视频', desc: '短视频平台矩阵覆盖' },
    { icon: BookOpen, title: '百科创建', desc: '权威百科词条创建服务' },
    { icon: Sparkles, title: '品牌宝', desc: '品牌信息管理与优化' },
    { icon: PenTool, title: '软文代写', desc: '专业内容创作服务' },
    { icon: Globe2, title: '更多资源', desc: '持续拓展中的媒体资源' },
  ];

  const gemStages = [
    { title: 'Monitor', desc: '全平台表现追踪' },
    { title: 'Analyze', desc: '洞察品牌与竞品差距' },
    { title: 'Alert', desc: '发现声量与认知异常' },
    { title: 'Improve', desc: '持续修正内容资产' },
  ];

  return (
    <div className="premium-page min-h-screen bg-white">
      <div className="scroll-progress" style={{ transform: `scaleX(${scrollProgress})` }} />
      {/* 微信悬浮球 */}
      <div 
        className="wechat-float fixed bottom-8 right-8 z-50 flex flex-col items-end"
        onMouseEnter={() => setIsWechatHovered(true)}
        onMouseLeave={() => setIsWechatHovered(false)}
      >
        {/* 二维码弹窗 */}
        {isWechatHovered && (
          <div className="premium-popover mb-4 p-6 bg-white rounded-xl shadow-2xl w-80 transform transition-all duration-300 scale-100 origin-bottom-right">
            <div className="text-center mb-4">
              <h3 className="text-xl font-bold text-gray-800">立即联系我们</h3>
            </div>
            <div className="flex justify-center mb-4">
              <img src={wechatQrcode} alt="企业微信二维码" className="w-48 h-48 object-contain" />
            </div>
            <p className="text-center text-sm text-gray-600 mb-4">
              扫码添加企业微信 • 2分钟响应
            </p>
            <div className="text-center">
              <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-full transition-colors">
                18817711181
              </button>
              <p className="text-xs text-gray-500 mt-2">工作日 9:00-18:00</p>
            </div>
          </div>
        )}
        
        {/* 悬浮按钮 */}
        <button 
          className="premium-floating-button flex items-center justify-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-full shadow-lg transition-all duration-300 transform hover:scale-105"
        >
          <MessageSquare size={24} className="mr-2" />
          微信咨询
        </button>
      </div>
      {/* 导航栏 */}
      <nav className={`premium-nav fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/95 backdrop-blur-md shadow-md' : 'bg-white'
      }`}>
        <div className="container-custom">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center space-x-3 cursor-pointer" onClick={() => scrollToSection('home')}>
              <img src={logoImage} alt="氧气科技" className="h-16 w-auto" />
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
                首页
              </button>
              <a href="http://aiagent.o2bp.com:8081/" target="_blank" rel="noopener noreferrer" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
                GEO智能体
              </a>
              <a href="https://pr.o2bp.com/" target="_blank" rel="noopener noreferrer" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
                GEO发稿
              </a>
              <a href="#gem-global" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
                GEM
              </a>
              <button onClick={() => scrollToSection('about')} className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
                关于我们
              </button>
              <button onClick={() => scrollToSection('contact')} className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
                联系我们
              </button>
              <Button 
                onClick={() => setIsLoginModalOpen(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-2"
              >
                <User size={18} />
                个人账户
              </Button>
            </div>

            <button 
              className="md:hidden text-gray-700"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {isMenuOpen && (
            <div className="md:hidden py-4 border-t border-gray-200">
              <div className="flex flex-col space-y-4">
                <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-blue-600 transition-colors text-left">
                  首页
                </button>
                <a href="http://aiagent.o2bp.com:8081/" target="_blank" rel="noopener noreferrer" className="text-gray-700 hover:text-blue-600 transition-colors text-left">
                  GEO智能体
                </a>
                <a href="https://pr.o2bp.com/" target="_blank" rel="noopener noreferrer" className="text-gray-700 hover:text-blue-600 transition-colors text-left">
                  GEO发稿
                </a>
                <a href="#gem-global" onClick={() => setIsMenuOpen(false)} className="text-gray-700 hover:text-blue-600 transition-colors text-left">
                  GEM
                </a>
                <button onClick={() => scrollToSection('about')} className="text-gray-700 hover:text-blue-600 transition-colors text-left">
                  关于我们
                </button>
                <button onClick={() => scrollToSection('contact')} className="text-gray-700 hover:text-blue-600 transition-colors text-left">
                  联系我们
                </button>
                <Button 
                  onClick={() => setIsLoginModalOpen(true)}
                  className="bg-blue-600 hover:bg-blue-700 text-white w-full flex items-center justify-center gap-2"
                >
                  <User size={18} />
                  个人账户
                </Button>
              </div>
            </div>
          )}
        </div>
      </nav>

      {activeArticle ? (
        <NewsArticlePage article={activeArticle} />
      ) : isNewsArchiveOpen ? (
        <NewsArchivePage articles={companyNews} />
      ) : isGemGlobalPageOpen ? (
        <GemGlobalPage />
      ) : (
        <>
      {/* 主视觉区 */}
      <section id="home" className="hero-section liquid-video-hero relative w-full h-screen overflow-hidden">
        <div className="absolute inset-0 z-0">
          <video
            className="hero-background-video"
            autoPlay
            muted
            loop
            playsInline
            preload="auto"
            aria-hidden="true"
          >
            <source src={BG_VIDEO} type="video/mp4" />
          </video>
          <div className="hero-video-scrim"></div>
        </div>
        <div className="liquid-hero-content absolute bottom-0 left-0 z-20 px-6 sm:px-12 pb-10 sm:pb-16 max-w-2xl" data-reveal>
          <h1 className="text-white text-4xl sm:text-5xl lg:text-6xl font-medium leading-tight tracking-tight mb-4">
            <span className="hero-title-line">GEO 赋能品牌</span>
            <span className="hero-title-line">抢占 AI 搜索时代新先机</span>
          </h1>
          <p className="text-white/60 text-sm leading-relaxed mb-7 max-w-md">
            人工智能生成式引擎优化 Generative Engine Optimization。氧气科技专注于品牌GEO优化，通过独家STREAM五维分析方法论，帮助品牌在主流大模型平台上脱颖而出。
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <a href="http://aiagent.o2bp.com:8081/" target="_blank" rel="noopener noreferrer" className="liquid-start-button">
              免费品牌诊断
            </a>
            <button onClick={() => scrollToSection('stream-method')} className="liquid-glass liquid-discover-button">
              了解 STREAM 方法论
            </button>
          </div>
        </div>
	      </section>
	
	      {/* 覆盖主流AI平台模块 - 新增 */}
	      <section id="ai-platforms" className="premium-band section-padding bg-gray-50">
	        <div className="container-custom" data-reveal>
	          <div className="text-center mb-12">
	            <h2 className="text-4xl md:text-5xl font-bold mb-4">
	              覆盖<span className="blue-gradient-text">主流AI平台</span>
	            </h2>
	            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
	              全面监测和优化您的品牌在各大模型平台的表现
	            </p>
	            <SectionGlobalStrip items={['APAC', 'EUROPE', 'NORTH AMERICA', 'GLOBAL AI SEARCH']} />
	          </div>
            <div className="platform-intelligence-bar" aria-hidden="true">
              <span>LLM VISIBILITY</span>
              <i></i>
              <span>AI ANSWER SHARE</span>
              <i></i>
              <span>BRAND CITATION SIGNAL</span>
              <i></i>
              <span>CROSS-REGION TRACKING</span>
            </div>
            <div className="ai-logo-loop-shell">
              <LogoLoop
                logos={aiPlatformLogos}
                speed={72}
                direction="left"
                logoHeight={54}
                gap={24}
                hoverSpeed={14}
                fadeOut
                fadeOutColor="#fbfdff"
                scaleOnHover
                renderItem={renderAiPlatformLogo}
                ariaLabel="主流AI平台logo滚动展示"
              />
            </div>
	        </div>
	      </section>
	
	      {/* GEO智能体介绍 */}
      <section id="geo-studio" className="premium-section section-padding bg-white">
        <div className="container-custom" data-reveal>
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              <span className="blue-gradient-text">GEO智能体</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              大模型时代的品牌追踪与竞品分析平台
            </p>
            <SectionGlobalStrip items={['GLOBAL MODEL MONITORING', 'COMPETITOR INTELLIGENCE', 'MARKET SIGNALS']} />
          </div>

          <div className="product-layout grid md:grid-cols-2 gap-12 items-center">
            <div className="product-copy-panel space-y-6">
              <h3 className="text-3xl font-bold text-gray-800">实时监测主流大模型平台</h3>
              <p className="text-lg text-gray-600 leading-relaxed">
                GEO智能体为您提供全方位的品牌在大模型平台上的表现监测，包括豆包、通义千问、KIMI、元宝、DeepSeek等主流AI平台。
              </p>
              <ul className="space-y-3">
                <li className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="text-gray-700">实时追踪品牌在各大模型平台的曝光情况</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="text-gray-700">深度竞品分析，洞察行业趋势</span>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="text-gray-700">数据可视化，一目了然掌握品牌表现</span>
                </li>
              </ul>
              <div className="pt-4">
                <a href="http://aiagent.o2bp.com:8081/" target="_blank" rel="noopener noreferrer">
                  <Button className="bg-blue-600 hover:bg-blue-700 text-white text-lg px-8 py-6">
                    访问 GEO智能体 →
                  </Button>
                </a>
              </div>
            </div>
            <div className="visual-frame product-visual-frame animate-fade-in-up animate-delay-200">
              <video
                className="geo-agent-video w-full h-auto"
                src="/geo-agent-demo.mp4"
                autoPlay
                muted
                loop
                playsInline
                aria-label="GEO智能体演示视频"
              />
            </div>
          </div>
        </div>
      </section>

      {/* 全渠道媒体投放 */}
      <section id="geo-publish" className="premium-section section-padding bg-white">
        <div className="container-custom" data-reveal>
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              <span className="blue-gradient-text">全渠道媒体投放</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              基于多年GEO经验与大模型信源收录倾向性构建的智能媒体投放平台
            </p>
            <SectionGlobalStrip items={['GLOBAL MEDIA NETWORK', 'SOURCE AUTHORITY', '24H DISTRIBUTION']} />
          </div>

          <div className="publish-layout flex flex-col lg:flex-row gap-12 items-center">
            <div className="visual-frame product-visual-frame w-full lg:w-1/2">
              <img src={geoPublishFull} alt="全渠道媒体投放平台" className="w-full h-auto" />
            </div>
            <div className="w-full lg:w-1/2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {geoPublishFeatures.map((item, index) => (
                  <div key={index} className="feature-card bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0"></div>
                      <div>
                        <h4 className="font-bold text-gray-800 mb-1">{item.title}</h4>
                        <p className="text-sm text-gray-600">{item.desc}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-16">
            <h3 className="text-3xl font-bold text-center mb-12">我们的资源</h3>
            <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6">
              {geoPublishResources.map((item, index) => {
                const Icon = item.icon
                return (
                  <div key={index} className="resource-card bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow text-center">
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Icon className="w-8 h-8 text-blue-600" />
                    </div>
                    <h4 className="text-lg font-bold text-gray-800 mb-2">{item.title}</h4>
                    <p className="text-sm text-gray-600">{item.desc}</p>
                  </div>
                )
              })}
            </div>
          </div>

          <div className="text-center mt-12">
            <a href="https://pr.o2bp.com/" target="_blank" rel="noopener noreferrer">
              <Button className="bg-blue-600 hover:bg-blue-700 text-white text-lg px-8 py-6">
                访问全渠道媒体投放平台 →
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* GEM 海外服务 */}
      <section id="gem" className="gem-section premium-section section-padding bg-white">
        <div className="container-custom" data-reveal>
          <div className="gem-panel">
            <p className="gem-kicker">海外服务</p>
            <div className="gem-title-row">
              <h2>GEM</h2>
              <span>Generative Engine Management</span>
            </div>
            <div className="gem-content-row">
              <p>
                围绕监测、分析、预警和持续优化，形成品牌在生成式引擎中的长期管理闭环。
              </p>
              <div className="gem-stage-grid">
                {gemStages.map((item) => (
                  <div key={item.title} className="gem-stage">
                    <h3>{item.title}</h3>
                    <span>{item.desc}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* STREAM 方法论 */}
      <section id="stream-method" className="premium-band section-padding gradient-bg">
        <div className="container-custom" data-reveal>
          <div className="stream-method-head text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              STREAM 五维分析方法论
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              氧气科技独家研发，全方位提升品牌在AI时代的可见度
            </p>
          </div>

          <div className="stream-card-grid" aria-label="STREAM 五维分析方法论">
            {streamData.map((item, index) => (
              <div key={index} className="stream-card">
                <div className="stream-card-letter">
                  <span>{item.letter}</span>
                </div>
                <h3>{item.title}（{item.letter}）</h3>
                <p>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 合作案例 LOGO 墙 */}
      <section id="cases" className="case-wall-section section-padding bg-[#f6f7fa]">
        <div className="container-custom" data-reveal>
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              <span className="blue-gradient-text">合作案例</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              我们已成功赋能多个行业头部品牌，实现AI时代的品牌价值重塑
            </p>
            <SectionGlobalStrip items={['GLOBAL BRAND PORTFOLIO', 'LUXURY', 'FMCG', 'TECHNOLOGY', 'EDUCATION']} />
          </div>
          <div className="w-full flex justify-center">
            <div className="case-proof-grid" aria-hidden="true">
              <span>Luxury</span>
              <span>FMCG</span>
              <span>Technology</span>
              <span>Education</span>
              <span>Global Brands</span>
            </div>
            <img 
              src={cooperationCases} 
              alt="合作案例" 
              className="w-full max-w-6xl h-auto"
            />
          </div>
        </div>
      </section>

      {/* 企业动态 */}
      <section id="news" className="news-section premium-section section-padding bg-white">
        <div className="container-custom" data-reveal>
          <div className="news-section-head">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold">
                企业<span className="blue-gradient-text">动态</span>
              </h2>
              <p className="text-gray-600 mt-3">News & Insights</p>
            </div>
            <a href="#news/more" className="news-more-link">查看更多 →</a>
          </div>

          <div className="news-card-grid">
            {featuredNews.map((item) => {
              const articleIndex = companyNews.indexOf(item)
              return <NewsCard key={item.url || item.title} item={item} index={articleIndex} />
            })}
          </div>
        </div>
      </section>

      {/* 关于我们 */}
      <section id="about" className="premium-section section-padding bg-white">
        <div className="container-custom" data-reveal>
          <div className="about-redesign">
            <div className="about-intro-grid">
              <div>
                <p className="about-kicker">关于氧气科技</p>
                <h2>AI时代品牌优化专家</h2>
              </div>
              <div className="about-copy">
                <p>
                  氧气科技是一家专注于品牌GEO优化（Generative Engine Optimization）的创新型科技公司。我们深刻理解AI时代品牌营销的新挑战，致力于帮助企业在大模型搜索时代抢占先机。
                </p>
                <p>
                  核心产品GEO智能体与独家STREAM五维分析方法论，帮助企业提升在豆包、通义千问、KIMI、元宝、DeepSeek等主流大模型平台上的品牌可见度和影响力。
                </p>
                <div className="about-proof-row">
                  <span>独家STREAM五维分析</span>
                  <span>全平台覆盖监测</span>
                  <span>AI时代品牌优化专家</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ 常见问题解答 */}
      <section id="faq" className="premium-section section-padding bg-white">
        <div className="container-custom" data-reveal>
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              常见<span className="blue-gradient-text">问题解答</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              了解更多关于GEO优化的信息
            </p>
            <SectionGlobalStrip items={['GLOBAL GEO KNOWLEDGE BASE', 'AI SEARCH FAQ', 'TRUSTED SOURCE']} />
          </div>
          <div className="faq-layout max-w-3xl mx-auto space-y-6">
            {[
              {
                q: '什么是GEO？',
                a: '在AI时代，用户的搜索习惯正在从“关键词搜索”变为“与AI对话提问”。GEO（生成式引擎优化）的核心则是让您的品牌信息，能够被 AI大模型更精准、更全面、更优先地理解和推荐给用户。'
              },
              {
                q: '和传统的SEO有什么区别？',
                a: 'GEO取代传统 SEO 的“点击跳转”模式，实现“零跳转”的信息直达。SEO解决“被找到”问题，GEO解决“被理解且被采纳”问题。'
              },
              {
                q: '选择氧气科技做 GEO 优化的优势有哪些？',
                a: '氧气科技与小红书、抽音等平台建立了深度合作，独家获取其后台搜索关键词排名数据，构建行为数据模型。同时基于北京大学研发的独家STREAM算法逻辑体系，配合多模态Agent智能体系统，实现“监测-诊断-优化-投放”的闭环体系。'
              },
              {
                q: '信源如何识别、选择，如何判别信源的权重？',
                a: '目前品牌可以通过语料进入国产大模型的唯一通道是人民网语料库。氧气科技 这边掌握着人民网权重较高信源 4000 多条的白名单，可以赋能品牌在被大模型判定具有较高权重的媒体上精准写稿、发稿，从而被推荐；以及可以快速赋能品牌进入国家语料库的通道，让品牌成为被国家背书的品牌。'
              },
              {
                q: 'GEO 产生的成果是什么？GEO 计划如何推动成果达成？关键绩效指标（KPI）应如何追踪？',
                a: '氧气科技坚持以 RASS 导向为核心交付标准，承诺实现 80% 以上的精准收录覆盖率。GEO 技术方法论将为品牌带来更深层的价值，在于为品牌构建真正 AI 友好的内容生态系统，通过系统性的内容构建、语义优化与多模态协同，让 AI 不仅能看见品牌，更能深度理解并信任品牌，最终实现主动推荐的核心目标。'
              }
            ].map((item, index) => (
              <div key={index} className="faq-card bg-gray-50 p-6 rounded-xl shadow-md hover:shadow-lg transition-all">
                <h3 className="text-lg font-bold text-gray-800 mb-3">
                  <span className="text-blue-600">Q:</span> {item.q}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  <span className="text-blue-600">A:</span> {item.a}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 联系我们 */}
      <section id="contact" className="premium-cta section-padding bg-gray-50">
        <div className="container-custom" data-reveal>
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              立即开启您的<span className="blue-gradient-text">品牌GEO优化</span>之旅
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              注册个人账户，获取免费品牌诊断报告和积分奖励
            </p>
            <SectionGlobalStrip items={['GLOBAL AI SEARCH GROWTH', 'BRAND VISIBILITY', 'O2 GEO']} />
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                onClick={() => setIsLoginModalOpen(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white text-lg px-10 py-6"
              >
                注册/登录
              </Button>
              <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50 text-lg px-10 py-6">
                联系销售
              </Button>
            </div>
            <div className="contact-grid mt-12 grid md:grid-cols-3 gap-8 text-left">
              <div className="contact-card bg-gradient-to-br from-blue-50 to-white p-6 rounded-xl shadow-md">
                <div className="text-blue-600 mb-3">
<Mail size={32} className="text-blue-600" />
                </div>
                <h3 className="font-bold text-gray-800 mb-2">邮箱</h3>
                <p className="text-gray-600">geo@o2qq.com</p>
              </div>
              <div className="contact-card bg-gradient-to-br from-blue-50 to-white p-6 rounded-xl shadow-md">
                <div className="text-blue-600 mb-3">
<MessageSquare size={32} className="text-blue-600" />
                </div>
                <h3 className="font-bold text-gray-800 mb-2">微信</h3>
                <p className="text-gray-600">wxid_x7068fxuurm122</p>
              </div>
              <div className="contact-card bg-gradient-to-br from-blue-50 to-white p-6 rounded-xl shadow-md">
                <div className="text-blue-600 mb-3">
<MapPin size={32} className="text-blue-600" />
                </div>
                <h3 className="font-bold text-gray-800 mb-2">地址</h3>
                <p className="text-gray-600">上海市徐汇区龙华街道龙文路199号国际传媒港F1栋18楼1810室</p>
              </div>
            </div>
          </div>
        </div>
      </section>
        </>
      )}

      {/* 页脚 */}
      <footer className="premium-footer bg-white border-t border-gray-200 py-12">
        <div className="container-custom">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            {/* 第一列：公司简介和Logo墙 */}
            <div className="md:col-span-2">
              <h3 className="text-2xl font-bold text-gray-800 mb-4">氧气科技</h3>
              <p className="text-gray-600 text-sm mb-6 leading-relaxed">
                氧气科技独家GEO STREAM技术融合为布的品牌AI工具，通过运用生成式技术，系统性管理和优化您的品牌信息，以确保品牌在AI的各类信息平台（如AI搜索、智能助手、对话机器人等）上，能够被准确识别、优先推荐（Recommended），并且可见（Visible）。
              </p>
              <SectionGlobalStrip items={['GLOBAL GEO OPERATIONS', 'AI SEARCH', 'BRAND INTELLIGENCE']} />
              <div className="mb-6">
                <img 
                  src={footerLogos} 
                  alt="合作伙伴" 
                  className="max-w-full h-auto"
                />
              </div>
            </div>
            {/* 第三列：联系我们 */}
            <div>
              <h4 className="text-xl font-bold text-gray-800 mb-4">联系我们</h4>
              <ul className="space-y-3 text-gray-600 text-sm">
                <li>
                  <span className="font-semibold">邮箱：</span> geo@o2qq.com
                </li>
                <li>
                  <span className="font-semibold">企业微信：</span> wxid_x7068fxuurm122
                </li>
                <li>
                  <span className="font-semibold">备案号：</span> <a href="#" className="text-blue-600 hover:underline">京ICP备2025148502号</a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-200 pt-6 text-center text-gray-500 text-sm">
            <p>© 2025 氧气科技。保留所有权利。</p>
          </div>
        </div>
      </footer>

      {/* 登录/注册模态框 */}
      {isLoginModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-[100] flex items-center justify-center p-4" onClick={() => setIsLoginModalOpen(false)}>
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-bold text-gray-800">个人账户</h3>
              <button onClick={() => setIsLoginModalOpen(false)} className="text-gray-500 hover:text-gray-700">
                <X size={24} />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">邮箱</label>
                <input 
                  type="email" 
                  placeholder="请输入您的邮箱"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">密码</label>
                <input 
                  type="password" 
                  placeholder="请输入密码"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3">
                登录
              </Button>
              <div className="text-center text-sm text-gray-600">
                还没有账户？<button className="text-blue-600 hover:underline">立即注册</button>
              </div>
              <div className="pt-4 border-t border-gray-200">
                <p className="text-sm text-gray-500 text-center">
                  登录后可查看个人积分和品牌分析报告
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default App
